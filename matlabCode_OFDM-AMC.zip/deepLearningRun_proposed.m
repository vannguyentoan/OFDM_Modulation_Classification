clear
% read the data from the folder "dataset" placed in the same location with the file.
% the dataset can be downloaded with the link in the dataset_description.txt
imds = imageDatastore('dataset\','IncludeSubfolders',true,'LabelSource','foldernames','FileExtensions',{'.mat'});
[imdsTrain,imdsTest] = splitEachLabel(imds,0.7,'randomized');

imdsTrain.Labels = categorical(imdsTrain.Labels);
imdsTrain.ReadFcn = @readFcnMatFile;
 
imdsTest.Labels = categorical(imdsTest.Labels);
imdsTest.ReadFcn = @readFcnMatFile;
labelCount = countEachLabel(imds)

batchSize   = 256;
ValFre      = fix(length(imdsTrain.Files)/batchSize);
options = trainingOptions('sgdm', ...
    'MiniBatchSize',batchSize, ...
    'MaxEpochs',90, ...
    'Shuffle','every-epoch',...
    'InitialLearnRate',0.01, ...
    'LearnRateSchedule','piecewise',...
    'LearnRateDropPeriod',30,...
    'LearnRateDropFactor',0.1,...
    'ValidationData',imdsTest, ...
    'ValidationFrequency',ValFre, ...
    'ValidationPatience',Inf, ...
    'Verbose',true ,...
    'VerboseFrequency',ValFre,...
    'Plots','training-progress',...
    'CheckpointPath','checkpoint',...
    'ExecutionEnvironment','multi-gpu');
trainednet = trainNetwork(imdsTrain,lgraph,options);

tic 
YPred = classify(trainednet,imdsTest,'MiniBatchSize',512,'ExecutionEnvironment','gpu');
toc
YTest = imdsTest.Labels;
accuracy = sum(YPred == YTest)/numel(YTest)





















