
% OFDMsym-Net

lgraph = layerGraph();
L = 32;

tempLayers = [
    imageInputLayer([20 80 2],"Name","input")
    convolution2dLayer([1 7],L,"Name","conv_1x7_a","Padding","same")
    batchNormalizationLayer("Name","bn_1x7_a")
    eluLayer(1,"Name","elu_1x7_a")
    maxPooling2dLayer([1 3],"Name","maxpool_1","Padding","same","Stride",[1 2])
    convolution2dLayer([1 7],L,"Name","conv_1x7_b","Padding","same")
    batchNormalizationLayer("Name","bn_1x7_b")
    eluLayer(1,"Name","elu_1x7_b")
    maxPooling2dLayer([1 3],"Name","maxpool_2","Padding","same","Stride",[1 2])
    convolution2dLayer([1 1],L,"Name","X1_conv_1x1","Padding","same")
    batchNormalizationLayer("Name","X1_bn_1x1")
    eluLayer(1,"Name","X1_elu_1x1")
    maxPooling2dLayer([1 3],"Name","X1_maxpool","Padding","same","Stride",[1 2])];
lgraph = addLayers(lgraph,tempLayers);

tempLayers = [
    convolution2dLayer([1 3],L,"Name","X1_conv1","Padding","same")
    batchNormalizationLayer("Name","X1_bn1")
    eluLayer(1,"Name","X1_elu1")
    dropoutLayer(0.1,"Name","X1_dropout_1")];
lgraph = addLayers(lgraph,tempLayers);

tempLayers = additionLayer(2,"Name","X1_addition_1");
lgraph = addLayers(lgraph,tempLayers);

tempLayers = [
    convolution2dLayer([1 3],L,"Name","X1_conv2","Padding","same")
    batchNormalizationLayer("Name","X1_bn2")
    eluLayer(1,"Name","X1_elu2")
    dropoutLayer(0.1,"Name","X1_dropout_2")];
lgraph = addLayers(lgraph,tempLayers);

tempLayers = additionLayer(2,"Name","X1_addition_2");
lgraph = addLayers(lgraph,tempLayers);

tempLayers = [
    depthConcatenationLayer(2,"Name","X1_depthcat")
    convolution2dLayer([1 1],L,"Name","Y1_conv_1x1","Padding","same")
    batchNormalizationLayer("Name","Y1_bn_1x1")
    eluLayer(1,"Name","Y1_elu_1x1")
    maxPooling2dLayer([3 1],"Name","Y1_maxpool","Padding","same","Stride",[2 1])];
lgraph = addLayers(lgraph,tempLayers);

tempLayers = [
    convolution2dLayer([3 1],L,"Name","Y1_conv1","Padding","same")
    batchNormalizationLayer("Name","Y1_bn1")
    eluLayer(1,"Name","Y1_elu1")
    dropoutLayer(0.1,"Name","Y1_dropout_1")];
lgraph = addLayers(lgraph,tempLayers);

tempLayers = additionLayer(2,"Name","Y1_addition_1");
lgraph = addLayers(lgraph,tempLayers);

tempLayers = [
    convolution2dLayer([3 1],L,"Name","Y1_conv2","Padding","same")
    batchNormalizationLayer("Name","Y1_bn2")
    eluLayer(1,"Name","Y1_elu2")
    dropoutLayer(0.1,"Name","Y1_dropout_2")];
lgraph = addLayers(lgraph,tempLayers);

tempLayers = additionLayer(2,"Name","Y1_addition_2");
lgraph = addLayers(lgraph,tempLayers);

tempLayers = [
    depthConcatenationLayer(2,"Name","Y1_depthcat")
    convolution2dLayer([1 1],L,"Name","X2_conv_1x1","Padding","same")
    batchNormalizationLayer("Name","X2_bn_1x1")
    eluLayer(1,"Name","X2_elu_1x1")
    maxPooling2dLayer([1 3],"Name","X2_maxpool","Padding","same","Stride",[1 2])];
lgraph = addLayers(lgraph,tempLayers);

tempLayers = [
    convolution2dLayer([1 3],L,"Name","X2_conv1","Padding","same")
    batchNormalizationLayer("Name","X2_bn1")
    eluLayer(1,"Name","X2_elu2_1")
    dropoutLayer(0.1,"Name","X2_dropout_1")];
lgraph = addLayers(lgraph,tempLayers);

tempLayers = additionLayer(2,"Name","X2_addition_1");
lgraph = addLayers(lgraph,tempLayers);

tempLayers = [
    convolution2dLayer([1 3],L,"Name","X2_conv2","Padding","same")
    batchNormalizationLayer("Name","X2_bn2")
    eluLayer(1,"Name","X2_elu2_2")
    dropoutLayer(0.1,"Name","X2_dropout_2")];
lgraph = addLayers(lgraph,tempLayers);

tempLayers = additionLayer(2,"Name","X2_addition_2");
lgraph = addLayers(lgraph,tempLayers);

tempLayers = [
    depthConcatenationLayer(2,"Name","X2_depthcat")
    convolution2dLayer([1 1],L,"Name","Y2_conv_1x1","Padding","same")
    batchNormalizationLayer("Name","Y2_bn_1x1")
    eluLayer(1,"Name","Y2_elu_1x1")
    maxPooling2dLayer([3 1],"Name","Y2_maxpool","Padding","same","Stride",[2 1])];
lgraph = addLayers(lgraph,tempLayers);

tempLayers = [
    convolution2dLayer([3 1],L,"Name","Y2_conv1","Padding","same")
    batchNormalizationLayer("Name","Y2_bn1")
    eluLayer(1,"Name","Y2_elu1")
    dropoutLayer(0.1,"Name","Y2_dropout_1")];
lgraph = addLayers(lgraph,tempLayers);

tempLayers = additionLayer(2,"Name","Y2_addition_1");
lgraph = addLayers(lgraph,tempLayers);

tempLayers = [
    convolution2dLayer([3 1],L,"Name","Y2_conv2","Padding","same")
    batchNormalizationLayer("Name","Y2_bn2")
    eluLayer(1,"Name","Y2_elu2")
    dropoutLayer(0.1,"Name","Y2_dropout_2")];
lgraph = addLayers(lgraph,tempLayers);

tempLayers = additionLayer(2,"Name","Y2_addition_2");
lgraph = addLayers(lgraph,tempLayers);

tempLayers = [
    depthConcatenationLayer(2,"Name","Y2_depthcat")
    globalAveragePooling2dLayer("Name","gap")
    fullyConnectedLayer(32,"Name","fc1")
    eluLayer(1,"Name","elu_fc1")
    dropoutLayer(0.1,"Name","dropout_fc1")
    fullyConnectedLayer(4,"Name","fc2")
    softmaxLayer("Name","softmax")
    classificationLayer("Name","classoutput")];
lgraph = addLayers(lgraph,tempLayers);

lgraph = connectLayers(lgraph,"X1_maxpool","X1_conv1");
lgraph = connectLayers(lgraph,"X1_maxpool","X1_addition_1/in2");
lgraph = connectLayers(lgraph,"X1_maxpool","X1_addition_2/in2");
lgraph = connectLayers(lgraph,"X1_dropout_1","X1_addition_1/in1");
lgraph = connectLayers(lgraph,"X1_addition_1","X1_conv2");
lgraph = connectLayers(lgraph,"X1_addition_1","X1_depthcat/in2");
lgraph = connectLayers(lgraph,"X1_dropout_2","X1_addition_2/in1");
lgraph = connectLayers(lgraph,"X1_addition_2","X1_depthcat/in1");
lgraph = connectLayers(lgraph,"Y1_maxpool","Y1_conv1");
lgraph = connectLayers(lgraph,"Y1_maxpool","Y1_addition_1/in2");
lgraph = connectLayers(lgraph,"Y1_maxpool","Y1_addition_2/in2");
lgraph = connectLayers(lgraph,"Y1_dropout_1","Y1_addition_1/in1");
lgraph = connectLayers(lgraph,"Y1_addition_1","Y1_conv2");
lgraph = connectLayers(lgraph,"Y1_addition_1","Y1_depthcat/in2");
lgraph = connectLayers(lgraph,"Y1_dropout_2","Y1_addition_2/in1");
lgraph = connectLayers(lgraph,"Y1_addition_2","Y1_depthcat/in1");
lgraph = connectLayers(lgraph,"X2_maxpool","X2_conv1");
lgraph = connectLayers(lgraph,"X2_maxpool","X2_addition_1/in2");
lgraph = connectLayers(lgraph,"X2_maxpool","X2_addition_2/in2");
lgraph = connectLayers(lgraph,"X2_dropout_1","X2_addition_1/in1");
lgraph = connectLayers(lgraph,"X2_addition_1","X2_conv2");
lgraph = connectLayers(lgraph,"X2_addition_1","X2_depthcat/in2");
lgraph = connectLayers(lgraph,"X2_dropout_2","X2_addition_2/in1");
lgraph = connectLayers(lgraph,"X2_addition_2","X2_depthcat/in1");
lgraph = connectLayers(lgraph,"Y2_maxpool","Y2_conv1");
lgraph = connectLayers(lgraph,"Y2_maxpool","Y2_addition_1/in2");
lgraph = connectLayers(lgraph,"Y2_maxpool","Y2_addition_2/in2");
lgraph = connectLayers(lgraph,"Y2_dropout_1","Y2_addition_1/in1");
lgraph = connectLayers(lgraph,"Y2_addition_1","Y2_conv2");
lgraph = connectLayers(lgraph,"Y2_addition_1","Y2_depthcat/in2");
lgraph = connectLayers(lgraph,"Y2_dropout_2","Y2_addition_2/in1");
lgraph = connectLayers(lgraph,"Y2_addition_2","Y2_depthcat/in1");

analyzeNetwork(lgraph);